<?php
// Don't edit this file!
$ver = '1.4';
$codename = 'Erwin'; // after Erwin Schrödinger, not some boring accountant in Germany.
$chup = 'http://minimacms.github.io';
$clurl = '#changelog';
$lang = 'International English';
$rburl = 'http://github.com/minimacms/minima-cms/issues';
?>
