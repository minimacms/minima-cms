 <h5>Sitename</h5>

      <p><?php $obj->update_sitename_form(); ?></p>
   
<h5>Theme</h5>

<p>Theming is since Minima 1.4 no longer handled via the database. Visit the <a href="<?php echo $clurl; ?>">changelog</a> for more information.</p>


