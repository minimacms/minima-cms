<?php $obj->manage_comments(); ?>
