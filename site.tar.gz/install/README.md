installer
=========

The new Minima installer.
